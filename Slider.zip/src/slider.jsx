import React, { useState } from "react";
import "./slider.css";

export function Slider() {
  const [value, setValue] = useState(50);

  return (
    <div className="slider-container">
      <input
        type="range"
        min={90}
        max={300}
        value={value}
        onChange={(e) => setValue(e.target.value)}
        className="slider"
      />
      <span>{value} lbs</span>
    </div>
  );
}

export default Slider;
